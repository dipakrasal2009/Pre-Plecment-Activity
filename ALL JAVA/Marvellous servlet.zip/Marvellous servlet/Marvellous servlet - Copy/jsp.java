<html>
<head><title>Hello World</title></head>
<body>
Hello World!<br/>
<%
out.println("Marvellous Infosystems");
%>
</body>
</html>